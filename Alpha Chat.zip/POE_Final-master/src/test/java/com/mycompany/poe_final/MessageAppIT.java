/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.poe_final;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.*;
/**
 *
 * @author RC_Student_lab
 */

public class MessageAppIT {

    private MessageApp app;

    @BeforeEach
    public void setUp() {
        app = new MessageApp();

        // Since addMessage() doesn't exist, we use sendMessage() instead.
        MessageApp.sendMessage("+27834557896", "Did you get the cake?");
        MessageApp.sendMessage("+27838884567", "Where are you? You are late! I have asked you to be on time.");
        MessageApp.sendMessage("+27834484567", "Yohoooo, I am at your gate.");
        MessageApp.sendMessage("0838884567", "It is dinner time!");
        MessageApp.sendMessage("+27838884567", "Ok, I am leaving without you.");
    }

    @Test
    public void testSentMessagesAreCorrect() {
        List<String> expected = Arrays.asList(
            "Did you get the cake?",
            "It is dinner time!"
        );
        assertEquals(expected, app.getMessagesByFlag("Sent"));
    }

    @Test
    public void testLongestMessage() {
        String expected = "Where are you? You are late! I have asked you to be on time.";
        assertEquals(expected, app.getLongestMessage());
    }

    @Test
    public void testMessagesByRecipient() {
        List<String> expected = Arrays.asList(
            "Where are you? You are late! I have asked you to be on time.",
            "Ok, I am leaving without you."
        );
        assertEquals(expected, app.getMessagesByRecipient("+27838884567"));
    }

    @Test
    public void testDeleteMessageByHash() {
        String msg = "Where are you? You are late! I have asked you to be on time.";
        String hash = app.getMessageHash(msg);
        assertTrue(app.deleteMessageByHash(hash));
        assertFalse(app.getMessagesByRecipient("+27838884567").contains(msg));
    }

    @Test
    public void testSentMessageReportStructure() {
        List<Map<String, String>> report = app.getSentMessageReport();
        assertEquals(2, report.size());

        for (Map<String, String> entry : report) {
            assertTrue(entry.containsKey("Message Hash"));
            assertTrue(entry.containsKey("Recipient"));
            assertTrue(entry.containsKey("Message"));
        }
    }
}

