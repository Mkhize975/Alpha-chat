/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.poe_final;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_lab
 */
public class MessageIT {

  @Test
    public void testConstructorAndGetters() {
        Message msg = new Message("+27834557896", "Did you get the cake?", "Sent");
        assertEquals("+27834557896", msg.getRecipient());
        assertEquals("Did you get the cake?", msg.getMessageText());
        assertEquals("Sent", msg.getFlag());
    }

    @Test
    public void testSetFlag() {
        Message msg = new Message("+27834557896", "Test", "Stored");
        msg.setFlag("Sent");
        assertEquals("Sent", msg.getFlag());
    }

    @Test
    public void testGenerateHashConsistency() {
        Message msg1 = new Message("+27834557896", "Same Content", "Sent");
        Message msg2 = new Message("+27834557896", "Same Content", "Sent");
        assertEquals(msg1.generateHash(), msg2.generateHash());
    }

    @Test
    public void testMessageIDLength() {
        Message msg = new Message("+27834557896", "Sample", "Sent");
        assertEquals(10, msg.getMessageID().length());
    }

    @Test
    public void testMessageCountIncrements() {
        int before = Message.getMessageCount();
        new Message("+27830000000", "Hello", "Sent");
        assertEquals(before + 1, Message.getMessageCount());
    }
}
